import{a as o}from"./react-vendor-sT__QgY4.js";var r,e;function t(){return e||(e=1,r=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")}),r}var s=t();const n=o(s),a=Object.freeze(Object.defineProperty({__proto__:null,default:n},Symbol.toStringTag,{value:"Module"}));export{a as b};
//# sourceMappingURL=browser-CJOC6Jpv.js.map
